# import argparse

# def parsertest(nr_paths: int, nr_parameters: int):

#     parser = argparse.ArgumentParser(prog = "Codac Assignment with PySpark")

#     parser.add_argument('--paths', type = str, nargs = nr_paths, default = ['../Data/dataset_one.csv', '../Data/dataset_one.csv'],
#                          help = "Paths to the local files containing the data")

#     parser.add_argument("--filters", type = str, nargs = nr_parameters, default = ["United Kingdom", "Netherlands"], help = "Filters to apply to our data")
#     args = parser.parse_args()

    
#     return args.paths, args.filters

from pyspark.sql import SparkSession
# import logging

#Spark Session with app name
spark = SparkSession\
    .builder\
    .master("local[*]")\
    .appName("pysparkAPP")\
    .config("spark.logConf", "true")\
    .getOrCreate()

data = [(1, "Mark", "Zuckerberg", "rh8HWfrrY","abc@gmail.com", "USA", "amex", 344512232),
          (2, "Emilia", "Clark", "1wjtPamAZ","csdd@gmail.com","France", "visa", 333345213)]

columns = ['id', 'first_name', 'last_name', 'btc_a','email', 'country', 'cc_t', 'cc_n']
df = spark.createDataFrame(data, columns)

new_names = {"cc_t": "credit_card_type", 
                "btc_a": "bitcoin_address", 
                "id": "client_identifier"}

for old_name,new_name in new_names.items():
    df = df.withColumnRenamed(old_name, new_name)

df.show(5)

# #logging module
# spark.sparkContext.setLogLevel("INFO")
# log4j = spark._jvm.org.apache.log4j
# logger = log4j.LogManager.getLogger("APP Logs:")
# logger.info('you log message ahaaaahahahaha')

# l = ["um", "dois", "tres"]
# print(isinstance(",".join(l),str))

